a=float(input("Enter the a value="))
b=float(input("Enter the B value"))
c=float(input("Enter the C value"))
if (a>b) and (a>c):
  l = a
elif (b>c)  :
  l=b
else:
  l=c  
print(l)  